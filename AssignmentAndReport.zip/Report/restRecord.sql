INSERT INTO `restaurant` (`restId`, `name`, `ownerId`, `restIcon`, `address`, `description`) VALUES
(1, 'McDonald', 423, 'Mcd.png', 'McDonald address', 'This is a fastfood restaurant');